# Beginner HTML Project - Student Attendance

## Features
- Add student names
- Mark as present
- Simple UI

## How to Run
1. Open index.html in browser

## Files
- index.html -> Main page
- style.css -> Styling
- script.js -> Logic
